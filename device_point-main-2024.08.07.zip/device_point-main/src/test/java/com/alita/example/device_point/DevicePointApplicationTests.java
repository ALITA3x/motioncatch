package com.alita.example.device_point;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevicePointApplicationTests {

    @Test
    void contextLoads() {
    }

}
